import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Github, Linkedin, Mail, ExternalLink, Code, Briefcase, Terminal, Zap } from "lucide-react"

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b border-primary/20 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-mono font-bold text-2xl text-primary flex items-center gap-2">
            <Terminal className="w-6 h-6" />
            <span className="text-foreground">~/</span>portfolio
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <a
              href="#about"
              className="text-sm font-mono hover:text-primary transition-colors glow-effect px-2 py-1 rounded"
            >
              ./about
            </a>
            <a
              href="#projects"
              className="text-sm font-mono hover:text-primary transition-colors glow-effect px-2 py-1 rounded"
            >
              ./projects
            </a>
            <a
              href="#skills"
              className="text-sm font-mono hover:text-primary transition-colors glow-effect px-2 py-1 rounded"
            >
              ./skills
            </a>
            <a
              href="#certifications"
              className="text-sm font-mono hover:text-primary transition-colors glow-effect px-2 py-1 rounded"
            >
              ./certs
            </a>
          </nav>
        </div>
      </header>

      <section className="relative py-24 px-4 text-center code-bg">
        <div className="container max-w-4xl mx-auto">
          <div className="mb-8 p-4 bg-card/50 rounded-lg terminal-border font-mono text-left max-w-md mx-auto">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
            </div>
            <div className="text-sm">
              <span className="text-primary">const</span> <span className="text-foreground">developer</span> = {"{"}
              <br />
              <span className="ml-4 text-primary">name:</span> <span className="text-yellow-400">"[Tu Nombre]"</span>,
              <br />
              <span className="ml-4 text-primary">role:</span>{" "}
              <span className="text-yellow-400">"Full Stack Developer"</span>
              <br />
              {"}"}
            </div>
          </div>

          <div className="mb-8">
            <img
              src="/professional-headshot.png"
              alt="Foto profesional"
              className="w-32 h-32 rounded-full mx-auto mb-6 border-4 border-primary shadow-lg glow-effect"
            />
          </div>
          <h1 className="font-mono font-bold text-5xl md:text-6xl mb-6 text-foreground text-balance">
            <span className="text-primary">&gt;</span> Hola, soy [Tu Nombre]
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 text-pretty font-mono">
            <span className="text-primary">//</span> Desarrollador Full Stack especializado en crear código limpio y
            soluciones escalables
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 glow-effect font-mono">
              <Code className="w-4 h-4 mr-2" />
              Ver Proyectos()
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="font-mono border-primary/50 hover:border-primary bg-transparent"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Descargar CV
            </Button>
          </div>
        </div>
      </section>

      <section id="about" className="py-20 px-4">
        <div className="container max-w-6xl mx-auto">
          <h2 className="font-mono font-bold text-4xl text-center mb-12 text-primary">
            <span className="text-foreground">function</span> aboutMe() {"{"}
          </h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="p-4 bg-card/30 rounded-lg terminal-border">
                <p className="text-lg leading-relaxed font-mono">
                  <span className="text-primary">return</span>{" "}
                  <span className="text-yellow-400">
                    `Desarrollador con +[X] años de experiencia construyendo aplicaciones robustas y escalables.
                    Especializado en JavaScript, Python y arquitecturas modernas.`
                  </span>
                </p>
              </div>
              <div className="p-4 bg-card/30 rounded-lg terminal-border">
                <p className="text-lg leading-relaxed font-mono">
                  <span className="text-primary">const</span> passion ={" "}
                  <span className="text-yellow-400">"Resolver problemas complejos con código elegante"</span>
                </p>
              </div>
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  size="sm"
                  className="font-mono border-primary/50 hover:border-primary glow-effect bg-transparent"
                >
                  <Github className="w-4 h-4 mr-2" />
                  GitHub
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="font-mono border-primary/50 hover:border-primary glow-effect bg-transparent"
                >
                  <Linkedin className="w-4 h-4 mr-2" />
                  LinkedIn
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="font-mono border-primary/50 hover:border-primary glow-effect bg-transparent"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Email
                </Button>
              </div>
            </div>
            <div className="relative">
              <img
                src="/developer-workspace-setup-with-multiple-monitors.jpg"
                alt="Espacio de trabajo"
                className="rounded-lg shadow-lg terminal-border"
              />
              <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground p-2 rounded-lg font-mono text-sm glow-effect">
                <Zap className="w-4 h-4 inline mr-1" />
                Coding Zone
              </div>
            </div>
          </div>
          <div className="text-center mt-8">
            <span className="font-mono text-primary text-2xl">{"}"}</span>
          </div>
        </div>
      </section>

      <section id="projects" className="py-20 px-4 bg-card/10">
        <div className="container max-w-6xl mx-auto">
          <h2 className="font-mono font-bold text-4xl text-center mb-12 text-primary">
            <span className="text-foreground">const</span> projects = [
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((project) => (
              <Card
                key={project}
                className="group hover:shadow-lg transition-all hover:glow-effect terminal-border bg-card/50"
              >
                <CardHeader className="p-0">
                  <img
                    src={`/modern-web-application-screenshot-project-.jpg?height=200&width=400&query=modern web application screenshot project ${project}`}
                    alt={`Proyecto ${project}`}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                </CardHeader>
                <CardContent className="p-6">
                  <CardTitle className="mb-2 text-card-foreground font-mono">
                    <span className="text-primary">project_</span>
                    {project}.js
                  </CardTitle>
                  <CardDescription className="mb-4 font-mono text-sm">
                    <span className="text-primary">//</span> Aplicación full-stack construida con tecnologías modernas.
                    Implementa mejores prácticas y arquitectura escalable.
                  </CardDescription>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="secondary" className="font-mono bg-primary/20 text-primary border-primary/30">
                      React
                    </Badge>
                    <Badge variant="secondary" className="font-mono bg-primary/20 text-primary border-primary/30">
                      Node.js
                    </Badge>
                    <Badge variant="secondary" className="font-mono bg-primary/20 text-primary border-primary/30">
                      MongoDB
                    </Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="font-mono border-primary/50 hover:border-primary bg-transparent"
                    >
                      <Github className="w-4 h-4 mr-2" />
                      Code
                    </Button>
                    <Button size="sm" className="font-mono bg-primary hover:bg-primary/90">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Live
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <span className="font-mono text-primary text-2xl">]</span>
          </div>
        </div>
      </section>

      <section id="skills" className="py-20 px-4">
        <div className="container max-w-6xl mx-auto">
          <h2 className="font-mono font-bold text-4xl text-center mb-12 text-primary">
            <span className="text-foreground">const</span> skills = {"{"}
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="terminal-border bg-card/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-card-foreground font-mono">
                  <Code className="w-5 h-5 text-primary" />
                  frontend: [
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "React", level: 90 },
                    { name: "TypeScript", level: 85 },
                    { name: "Next.js", level: 88 },
                    { name: "Tailwind", level: 92 },
                    { name: "Vue.js", level: 75 },
                  ].map((skill) => (
                    <div key={skill.name} className="space-y-2">
                      <div className="flex justify-between items-center font-mono text-sm">
                        <span className="text-primary">"{skill.name}":</span>
                        <span className="text-yellow-400">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all duration-1000 glow-effect"
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="terminal-border bg-card/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-card-foreground font-mono">
                  <Terminal className="w-5 h-5 text-primary" />
                  backend: [
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Node.js", level: 88 },
                    { name: "Python", level: 85 },
                    { name: "PostgreSQL", level: 80 },
                    { name: "MongoDB", level: 82 },
                    { name: "Docker", level: 75 },
                  ].map((skill) => (
                    <div key={skill.name} className="space-y-2">
                      <div className="flex justify-between items-center font-mono text-sm">
                        <span className="text-primary">"{skill.name}":</span>
                        <span className="text-yellow-400">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all duration-1000 glow-effect"
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="terminal-border bg-card/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-card-foreground font-mono">
                  <Briefcase className="w-5 h-5 text-primary" />
                  tools: [
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Git", level: 90 },
                    { name: "AWS", level: 78 },
                    { name: "Figma", level: 70 },
                    { name: "Jest", level: 82 },
                    { name: "Webpack", level: 75 },
                  ].map((skill) => (
                    <div key={skill.name} className="space-y-2">
                      <div className="flex justify-between items-center font-mono text-sm">
                        <span className="text-primary">"{skill.name}":</span>
                        <span className="text-yellow-400">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all duration-1000 glow-effect"
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          <div className="text-center mt-8">
            <span className="font-mono text-primary text-2xl">{"}"}</span>
          </div>
        </div>
      </section>

      <section id="certifications" className="py-20 px-4 bg-card/10">
        <div className="container max-w-6xl mx-auto">
          <h2 className="font-mono font-bold text-4xl text-center mb-12 text-primary">
            <span className="text-foreground">const</span> certifications = [
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { name: "AWS Certified Developer", org: "Amazon Web Services", year: "2023", icon: "☁️" },
              { name: "React Developer Certification", org: "Meta", year: "2023", icon: "⚛️" },
              { name: "Google Cloud Professional", org: "Google", year: "2022", icon: "🌐" },
              { name: "MongoDB Certified Developer", org: "MongoDB Inc.", year: "2022", icon: "🍃" },
              { name: "Scrum Master Certified", org: "Scrum Alliance", year: "2021", icon: "🏃" },
              { name: "JavaScript Algorithms", org: "freeCodeCamp", year: "2021", icon: "📜" },
            ].map((cert, index) => (
              <Card key={index} className="text-center terminal-border bg-card/30 hover:glow-effect transition-all">
                <CardHeader>
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 terminal-border">
                    <span className="text-2xl">{cert.icon}</span>
                  </div>
                  <CardTitle className="text-card-foreground font-mono text-sm">{cert.name}</CardTitle>
                  <CardDescription className="font-mono text-xs">
                    <span className="text-primary">//</span> {cert.org}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Badge variant="outline" className="font-mono border-primary/50 text-primary">
                    {cert.year}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <span className="font-mono text-primary text-2xl">]</span>
          </div>
        </div>
      </section>

      <footer className="py-12 px-4 bg-muted/20">
        <div className="container max-w-6xl mx-auto text-center">
          <div className="p-6 bg-card/30 rounded-lg terminal-border mb-8 max-w-2xl mx-auto">
            <h3 className="font-mono font-bold text-2xl mb-4 text-primary">
              <span className="text-foreground">if</span> (interested) {"{"}
            </h3>
            <p className="text-muted-foreground mb-6 font-mono">
              <span className="text-primary">//</span> Siempre abierto a nuevos desafíos y colaboraciones
            </p>
            <div className="flex justify-center gap-4 mb-4">
              <Button className="font-mono bg-primary hover:bg-primary/90 glow-effect">
                <Mail className="w-4 h-4 mr-2" />
                contact()
              </Button>
              <Button variant="outline" className="font-mono border-primary/50 hover:border-primary bg-transparent">
                <Github className="w-4 h-4 mr-2" />
                github
              </Button>
              <Button variant="outline" className="font-mono border-primary/50 hover:border-primary bg-transparent">
                <Linkedin className="w-4 h-4 mr-2" />
                linkedin
              </Button>
            </div>
            <div className="font-mono text-primary">{"}"}</div>
          </div>
          <p className="text-sm text-muted-foreground font-mono">
            <span className="text-primary">©</span> 2024 [Tu Nombre]. <span className="text-primary">//</span> Built
            with ❤️ and lots of ☕
          </p>
        </div>
      </footer>
    </div>
  )
}
